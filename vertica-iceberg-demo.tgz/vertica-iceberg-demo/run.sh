#!/usr/bin/env bash
# =============================================================================
#  vertica-iceberg-demo / run.sh
#  -----------------------------------------------------------------------------
#  1. Loads .env, validates mode 600.
#  2. Detects the Vertica version via SELECT version().
#  3. Detects the storage backend from ICEBERG_DIRECTORY's URL scheme.
#  4. Prints the feature support matrix for the detected version.
#  5. Decides the path:
#       - ICEBERG_METADATA set in .env  -> use it, skip writes
#       - v25.4+ and no metadata        -> Vertica writes its own table
#       - older + no metadata           -> print Missing/Fix example, exit
#  6. Runs Statement 1, 2, 3 from the docs page against the chosen table.
# =============================================================================
set -euo pipefail
trap 'ec=$?; [ $ec -ne 0 ] && \
  echo "ERROR: line $LINENO exited $ec; last cmd: $BASH_COMMAND" >&2' ERR
cd "$(dirname "$0")"


# ---- 0. load .env ----------------------------------------------------------
if [[ ! -f .env ]]; then
    cat <<EOF >&2
ERROR: .env not found.
  cp env.example .env
  chmod 600 .env
  \$EDITOR .env
EOF
    exit 1
fi

ENV_MODE=$(stat -c '%a' .env)
if [[ "$ENV_MODE" != "600" && "$ENV_MODE" != "400" ]]; then
    echo "ERROR: .env permissions are $ENV_MODE; must be 600 or 400 (chmod 600 .env)" >&2
    exit 1
fi

# shellcheck disable=SC1091
set -a; source .env; set +a

: "${ICEBERG_DIRECTORY:?set in .env (e.g. s3://iceberg-demo/sales)}"


# ---- 1. detect Vertica version --------------------------------------------
VSQL_FLAGS=( -U "${VSQL_USER:-dbadmin}" )
[[ -n "${VSQL_HOST:-}" ]] && VSQL_FLAGS+=( -h "$VSQL_HOST" )
[[ -n "${VSQL_PORT:-}" ]] && VSQL_FLAGS+=( -p "$VSQL_PORT" )
[[ -n "${VSQL_DB:-}"   ]] && VSQL_FLAGS+=( -d "$VSQL_DB"   )

run_vsql() { vsql "${VSQL_FLAGS[@]}" "$@"; }

if ! RAW_VERSION=$(run_vsql -tAc "SELECT version();" 2>/dev/null); then
    echo "ERROR: cannot reach Vertica with: vsql ${VSQL_FLAGS[*]}" >&2
    exit 1
fi

VERSION=$(echo "$RAW_VERSION" | sed 's/.* v//' | tr -d '[:space:]')
MAJOR=${VERSION%%.*}
MINOR_AND_REST=${VERSION#*.}
MINOR=${MINOR_AND_REST%%.*}

# Numeric comparison helper: 25.4 -> 2504, 12.0 -> 1200, 26.1 -> 2601
VER_NUM=$(( MAJOR * 100 + MINOR ))


# ---- 2. detect storage backend --------------------------------------------
case "$ICEBERG_DIRECTORY" in
    s3://*)   STORAGE_KIND=minio   ; STORAGE_LABEL="S3/MinIO" ;;
    hdfs://*) STORAGE_KIND=hdfs    ; STORAGE_LABEL="HDFS" ;;
    /*)       STORAGE_KIND=local   ; STORAGE_LABEL="local filesystem" ;;
    *)
        echo "ERROR: ICEBERG_DIRECTORY must start with s3://, hdfs://, or /" >&2
        echo "       got: $ICEBERG_DIRECTORY" >&2
        exit 1 ;;
esac


# ---- 3. print support matrix ----------------------------------------------
ck() { local since=$1; [[ $VER_NUM -ge $since ]] && echo "✓" || echo "✗"; }

cat <<EOF

==============================================================================
  vertica-iceberg-demo
==============================================================================
  Vertica detected : $VERSION
  Storage detected : $STORAGE_LABEL  (from ICEBERG_DIRECTORY=$ICEBERG_DIRECTORY)
  Iceberg target   : $ICEBERG_DIRECTORY
==============================================================================
  Iceberg feature support on this version
  (sourced from official Vertica docs at docs.vertica.com)
------------------------------------------------------------------------------
  CREATE EXTERNAL TABLE ICEBERG  (filesystem tables)   since 11.1   $(ck 1101)
  IcebergPathMapping                                   since 11.1   $(ck 1101)
  COLUMN TYPES override                                since 11.1   $(ck 1101)
  Iceberg v2 metadata reads                            since 23.4   $(ck 2304)
  Schema evolution on reads                            since 23.3   $(ck 2303)
  AWS Glue catalog                                     since 25.1   $(ck 2501)
  REST OpenAPI metastore                               since 25.2   $(ck 2502)
  Hive Metastore (HMS) catalog                         since 25.3   $(ck 2503)
  EXPORT TO ICEBERG  (filesystem catalog)              since 25.4   $(ck 2504)
==============================================================================
EOF


# ---- 4. decide which path to take -----------------------------------------
USE_BUNDLED_SAMPLES=0
RUN_WRITE_DEMO=0

if [[ -n "${ICEBERG_METADATA:-}" ]]; then
    METADATA_URL="$ICEBERG_METADATA"
    SOURCE_OF_METADATA="ICEBERG_METADATA from .env"
elif [[ $VER_NUM -ge 2504 ]]; then
    RUN_WRITE_DEMO=1
    METADATA_URL="${ICEBERG_DIRECTORY}/metadata/v1.metadata.json"
    SOURCE_OF_METADATA="freshly written by Vertica's EXPORT TO ICEBERG"
else
    # v < 25.4 and no ICEBERG_METADATA: print clear missing/fix message and exit.
    echo
    echo "Missing: ICEBERG_METADATA in .env"
    echo "         (this version cannot write Iceberg with EXPORT TO ICEBERG;"
    echo "          you must point the demo at an existing metadata.json)"
    echo
    case "$STORAGE_KIND" in
        minio)
            cat <<EOF
Fix example:
  ./bin/mc cp -r samples/sales/ localminio/iceberg-demo/sales/
  then add this line to .env:
    ICEBERG_METADATA=s3://iceberg-demo/sales/metadata/v1.metadata.json
EOF
            ;;
        hdfs)
            cat <<EOF
Fix example:
  hdfs dfs -mkdir -p /user/dbadmin/iceberg-demo
  hdfs dfs -put -f samples/sales /user/dbadmin/iceberg-demo/
  then add these lines to .env:
    ICEBERG_METADATA=hdfs://<your-nameservice>/user/dbadmin/iceberg-demo/sales/metadata/v1.metadata.json
  (the bundled samples embed s3://iceberg-demo/sales/ in their paths;
   Vertica's IcebergPathMapping will rewrite that to your HDFS path
   automatically — Statement 1 of the demo handles it.)
EOF
            ;;
        local)
            cat <<EOF
Fix example:
  cp -r samples/sales /var/iceberg-demo/   # any path readable by all Vertica nodes
  then add this line to .env:
    ICEBERG_METADATA=file:///var/iceberg-demo/sales/metadata/v1.metadata.json
EOF
            ;;
    esac
    echo
    exit 1
fi


# ---- 5. compute IcebergPathMapping ----------------------------------------
# If we're using the bundled samples (or any metadata that embeds
# s3://iceberg-demo/sales) but the user's actual storage is different,
# we set IcebergPathMapping to bridge the gap at query time.
EMBED_PREFIX="s3://iceberg-demo/sales"
if [[ "$ICEBERG_DIRECTORY" != "$EMBED_PREFIX" ]] && \
   [[ "$METADATA_URL" == *"$EMBED_PREFIX"* ]]; then
    PATH_MAPPING="{\"$EMBED_PREFIX\":\"$ICEBERG_DIRECTORY\"}"
    PATH_MAPPING_NOTE="bridging bundled samples ($EMBED_PREFIX) -> $ICEBERG_DIRECTORY"
else
    # No bridging needed — show the docs example to demonstrate the syntax.
    PATH_MAPPING='{"hdfs://demo.example.com:9000":"webhdfs://demo.example.com:9870"}'
    PATH_MAPPING_NOTE="syntax demo only (no real rewrite needed for this run)"
fi


# ---- 6. confirm what we're about to do ------------------------------------
cat <<EOF

==> Plan
       Read demo  : YES (always — works on every version since 11.1)
       Write demo : $([[ $RUN_WRITE_DEMO -eq 1 ]] && echo "YES (v25.4+)" || echo "NO  (this version pre-dates EXPORT TO ICEBERG)")
       metadata   : $METADATA_URL
                    ($SOURCE_OF_METADATA)
       path map   : $PATH_MAPPING_NOTE

EOF


# ---- 7. build the rendered SQL files --------------------------------------
case "$STORAGE_KIND" in
    minio|s3)
        if [[ -z "${MINIO_ACCESS_KEY:-}" || "$MINIO_ACCESS_KEY" == "REPLACE_ME" ]]; then
            echo "ERROR: MINIO_ACCESS_KEY not set in .env" >&2; exit 1
        fi
        if [[ -z "${MINIO_SECRET_KEY:-}" || "$MINIO_SECRET_KEY" == "REPLACE_ME" ]]; then
            echo "ERROR: MINIO_SECRET_KEY not set in .env" >&2; exit 1
        fi
        AWS_BLOCK=""
        AWS_ENDPOINT="${MINIO_ENDPOINT_HOST}:${MINIO_ENDPOINT_PORT}"
        AWS_AUTH="${MINIO_ACCESS_KEY}:${MINIO_SECRET_KEY}"
        ;;
    hdfs|local)
        AWS_BLOCK="-- "
        AWS_ENDPOINT=""
        AWS_AUTH=""
        ;;
esac

render() {
    local in=$1 out=$2
    sed \
        -e "s|__ICEBERG_DIRECTORY__|${ICEBERG_DIRECTORY}|g" \
        -e "s|__ICEBERG_METADATA__|${METADATA_URL}|g" \
        -e "s|__ICEBERG_PATH_MAPPING__|${PATH_MAPPING}|g" \
        -e "s|__AWS_ENDPOINT__|${AWS_ENDPOINT}|g" \
        -e "s|__AWS_USE_HTTPS__|${MINIO_USE_HTTPS:-0}|g" \
        -e "s|__AWS_REGION__|${MINIO_REGION:-us-east-1}|g" \
        -e "s|__AWS_AUTH__|${AWS_AUTH}|g" \
        -e "s|__AWS_BLOCK__|${AWS_BLOCK}|g" \
        "$in" > "$out"
    chmod 600 "$out"
}

trap 'shred -u .demo_*.sql 2>/dev/null; rm -f .demo_*.sql' EXIT

render 01_setup_session.sql.tmpl .demo_01.sql
[[ $RUN_WRITE_DEMO -eq 1 ]] && render 03_demo_write.sql.tmpl .demo_03.sql
render 02_demo_read.sql.tmpl .demo_02.sql


# ---- 8. concatenate into one SQL file & run ------------------------------
# Multiple -f flags on a single vsql invocation can split into separate
# executions where ALTER SESSION settings don't carry over.  Concatenating
# guarantees the whole demo runs in ONE session.
{ cat .demo_01.sql
  [[ $RUN_WRITE_DEMO -eq 1 ]] && cat .demo_03.sql
  cat .demo_02.sql
} > .demo_all.sql
chmod 600 .demo_all.sql

run_vsql -f .demo_all.sql

cat <<EOF

------------------------------------------------------------------------------
Done.
EOF
